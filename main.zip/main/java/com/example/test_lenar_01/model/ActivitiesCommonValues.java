package com.example.test_lenar_01.model;

import android.graphics.Bitmap;

import com.example.test_lenar_01.dataClasses.Tag;

import java.util.ArrayList;
import java.util.List;

public class ActivitiesCommonValues {
    public static List<Tag> chosenPostTagsList = new ArrayList<>();
    public static Bitmap chosenPostImage = null;
}
