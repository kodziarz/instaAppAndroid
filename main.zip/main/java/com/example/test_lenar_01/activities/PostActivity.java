package com.example.test_lenar_01.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.test_lenar_01.R;
import com.example.test_lenar_01.model.ActivitiesCommonValues;

public class PostActivity extends AppCompatActivity {

    ImageView imageView;
    Button editPostButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        imageView = findViewById(R.id.imageView);
        editPostButton = findViewById(R.id.editPostButton);

        imageView.setImageBitmap(ActivitiesCommonValues.chosenPostImage);

        editPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PostActivity.this, EditPostActivity.class);
                startActivity(intent);
            }
        });

    }
}