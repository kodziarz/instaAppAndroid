package com.example.test_lenar_01.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.test_lenar_01.R;
import com.example.test_lenar_01.adapters.TagsAdapter;
import com.example.test_lenar_01.dataClasses.Tag;

import java.util.ArrayList;
import java.util.List;

public class EditPostActivity extends AppCompatActivity {

    ListView listView;
    List<Tag> tagsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_post);

        tagsList = new ArrayList<Tag>(){
            {
                add(new Tag("tag1"));
                add(new Tag("tag1"));
                add(new Tag("tag1"));
                add(new Tag("tag1"));
                add(new Tag("tag1"));
                add(new Tag("tag1"));
                add(new Tag("tag1"));
            }
        };

        listView = findViewById(R.id.listView);

        listView.setAdapter(new TagsAdapter(EditPostActivity.this, tagsList));

    }
}